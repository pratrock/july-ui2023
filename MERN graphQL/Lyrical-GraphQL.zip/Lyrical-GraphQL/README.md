# Lyrical-GraphQL

Starter project from a GraphQL course on Udemy.com

### Setup

- Run `npm install --legacy-peer-deps` in the root of the project to install dependencies
- Access the application at `localhost:4000` in your browser
